#include <stdio.h>

const char *openblas_get_corename(void);

int main ()
{
  printf("corename: %s\n", openblas_get_corename());
  
  return 0;
}

